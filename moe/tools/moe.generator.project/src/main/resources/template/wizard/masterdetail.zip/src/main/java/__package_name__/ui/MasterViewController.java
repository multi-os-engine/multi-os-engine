package __package_name__.ui;

import org.moe.natj.general.Pointer;
import org.moe.natj.general.ann.*;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.SEL;
import org.moe.natj.objc.ann.ObjCClassName;
import org.moe.natj.objc.ann.Selector;
import org.moe.natj.objc.map.ObjCObjectMapper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import ios.coregraphics.c.CoreGraphics;
import ios.foundation.NSArray;
import ios.foundation.NSIndexPath;
import ios.uikit.UIBarButtonItem;
import ios.uikit.UIDevice;
import ios.uikit.UINavigationController;
import ios.uikit.UIStoryboardSegue;
import ios.uikit.UITableView;
import ios.uikit.UITableViewCell;
import ios.uikit.UITableViewController;
import ios.uikit.enums.UIBarButtonSystemItem;
import ios.uikit.enums.UITableViewCellEditingStyle;
import ios.uikit.enums.UITableViewRowAnimation;
import ios.uikit.enums.UIUserInterfaceIdiom;

@org.moe.natj.general.ann.Runtime(ObjCRuntime.class)
@ObjCClassName("MasterViewController")
@RegisterOnStartup
public class MasterViewController extends UITableViewController {

    private ArrayList<String> objects = new ArrayList<>();

    @Owned
    @Selector("alloc")
    public static native MasterViewController alloc();

    @Override
    public void awakeFromNib() {
        super.awakeFromNib();

        if (UIDevice.currentDevice().userInterfaceIdiom() == UIUserInterfaceIdiom.Pad) {
            setClearsSelectionOnViewWillAppear(false);
            setPreferredContentSize(CoreGraphics.CGSizeMake(320.0, 600.0));
        }
    }

    @Selector("init")
    public native MasterViewController init();

    @Override
    public long numberOfSectionsInTableView(UITableView uiTableView) {
        return 1;
    }

    @Override
    public boolean tableViewCanEditRowAtIndexPath(UITableView uiTableView, NSIndexPath nsIndexPath) {
        // Return NO if you do not want the specified item to be editable.
        return true;
    }

    @Override
    public UITableViewCell tableViewCellForRowAtIndexPath(UITableView uiTableView, NSIndexPath nsIndexPath) {
        UITableViewCell cell = (UITableViewCell) tableView().dequeueReusableCellWithIdentifierForIndexPath("Cell", nsIndexPath);
        cell.textLabel().setText(objects.get((int) nsIndexPath.row()));
        return cell;
    }

    @Override
    public void tableViewCommitEditingStyleForRowAtIndexPath(UITableView uiTableView, @NInt long l, NSIndexPath nsIndexPath) {
        if (l == UITableViewCellEditingStyle.Delete) {
            objects.remove(objects.get((int) nsIndexPath.row()));
            tableView().deleteRowsAtIndexPathsWithRowAnimation((NSArray<NSIndexPath>)NSArray.arrayWithObject(nsIndexPath), UITableViewRowAnimation.Fade);
        } else if (l == UITableViewCellEditingStyle.Insert) {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }

    @Override
    public long tableViewNumberOfRowsInSection(UITableView uiTableView, @NInt long l) {
        return objects.size();
    }

    @Override
    public void prepareForSegueSender(UIStoryboardSegue uiStoryboardSegue, @Mapped(ObjCObjectMapper.class) Object o) {
        super.prepareForSegueSender(uiStoryboardSegue, o);

        if (uiStoryboardSegue.identifier().equals("showDetail")) {
            NSIndexPath indexPath = tableView().indexPathForSelectedRow();
            String object = objects.get((int) indexPath.row());

            DetailViewController controller = (DetailViewController) ((UINavigationController) uiStoryboardSegue.destinationViewController()).topViewController();
            controller.setDetailItem(object);

            controller.navigationItem().setLeftBarButtonItem(splitViewController().displayModeButtonItem());
            controller.navigationItem().setLeftItemsSupplementBackButton(true);
        }
    }

    protected MasterViewController(Pointer peer) {
        super(peer);
    }

    @Override
    public void viewDidLoad() {
        // Do any additional setup after loading the view, typically from a nib.
        navigationItem().setLeftBarButtonItem(editButtonItem());

        UIBarButtonItem addButton = UIBarButtonItem.alloc().initWithBarButtonSystemItemTargetAction(UIBarButtonSystemItem.Add, this, new SEL("insertNewObject:"));
        navigationItem().setRightBarButtonItem(addButton);
    }

    @Generated
    @Selector("insertNewObject:")
    public void insertNewObject(Object sender) {
        String date = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss.SSS").format(new Date());
        objects.add(0, date);
        NSIndexPath indexPath = NSIndexPath.indexPathForRowInSection(0,0);
        tableView().insertRowsAtIndexPathsWithRowAnimation((NSArray<NSIndexPath>)NSArray.arrayWithObject(indexPath), UITableViewRowAnimation.Automatic);
    }
}
