package __package_name__.ui;

import org.moe.natj.general.Pointer;
import org.moe.natj.general.ann.Owned;
import org.moe.natj.general.ann.RegisterOnStartup;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCClassName;
import org.moe.natj.objc.ann.Selector;

import ios.uikit.UIViewController;

@org.moe.natj.general.ann.Runtime(ObjCRuntime.class)
@ObjCClassName("SecondViewController")
@RegisterOnStartup
public class SecondViewController extends UIViewController {

    protected SecondViewController(Pointer peer) {
        super(peer);
    }

    @Owned
    @Selector("alloc")
    public static native SecondViewController alloc();

    @Selector("init")
    public native SecondViewController init();
}