package __package_name__.ui;

import org.moe.natj.general.Pointer;
import org.moe.natj.general.ann.Owned;
import org.moe.natj.general.ann.RegisterOnStartup;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCClassName;
import org.moe.natj.objc.ann.Selector;

import apple.uikit.UIViewController;

@org.moe.natj.general.ann.Runtime(ObjCRuntime.class)
@ObjCClassName("FirstViewController")
@RegisterOnStartup
public class FirstViewController extends UIViewController {

    protected FirstViewController(Pointer peer) {
        super(peer);
    }

    @Owned
    @Selector("alloc")
    public static native FirstViewController alloc();

    @Selector("init")
    public native FirstViewController init();
}
