package __package_name__.ui;

import org.moe.natj.general.Pointer;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Owned;
import org.moe.natj.general.ann.RegisterOnStartup;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCClassName;
import org.moe.natj.objc.ann.Property;
import org.moe.natj.objc.ann.Selector;

import ios.uikit.UILabel;
import ios.uikit.UIViewController;

@org.moe.natj.general.ann.Runtime(ObjCRuntime.class)
@ObjCClassName("DetailViewController")
@RegisterOnStartup
public class DetailViewController extends UIViewController {

    private DetailViewController detailViewController;

    protected DetailViewController(Pointer peer) {
        super(peer);
    }

    private String detailItem = "";

    @Owned
    @Selector("alloc")
    public static native MasterViewController alloc();

    @Selector("init")
    public native MasterViewController init();

    @Generated
    @Property
    @Selector("detailDescriptionLabel")
    public native UILabel detailDescriptionLabel();

    @Generated
    @Property
    @Selector("setDetailDescriptionLabel:")
    public native void setDetailDescriptionLabel(UILabel object);

    private UILabel dataLabel;


    @Override
    public void viewDidLoad() {
        super.viewDidLoad();

        dataLabel = detailDescriptionLabel();
        // Do any additional setup after loading the view, typically from a nib.
        configureView();
    }

    public void configureView() {
        // Update the user interface for the detail item.
        if (!detailItem.equals("")) {
            if (dataLabel != null)
                dataLabel.setText(detailItem);
        }
    }

    public void setDetailItem(String newDetailItem) {
        if (!detailItem.equals(newDetailItem)) {
            detailItem = newDetailItem;

            // Update the view.
            configureView();
        }
    }

    public String getDetailItem() {
        return detailItem;
    }
}
