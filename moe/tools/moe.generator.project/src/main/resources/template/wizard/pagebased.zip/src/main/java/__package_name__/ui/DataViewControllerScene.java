package __package_name__.ui;

import org.moe.natj.general.Pointer;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Owned;
import org.moe.natj.general.ann.RegisterOnStartup;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCClassName;
import org.moe.natj.objc.ann.Property;
import org.moe.natj.objc.ann.Selector;

import apple.uikit.UILabel;
import apple.uikit.UIViewController;
import apple.uikit.enums.NSTextAlignment;

@Runtime(ObjCRuntime.class)
@ObjCClassName("DataViewControllerScene")
@RegisterOnStartup
public class DataViewControllerScene extends UIViewController {

    private String dataString;

    private UILabel dataLabel;

    @Owned
    @Selector("alloc")
    public static native DataViewControllerScene alloc();

    @Selector("init")
    public native DataViewControllerScene init();

    protected DataViewControllerScene(Pointer peer) {
        super(peer);
    }

    @Generated
    @Property
    @Selector("dataLabel")
    public native UILabel getDataLabel();

    @Generated
    @Property
    @Selector("setDataLabel:")
    public native void setDataLabel(UILabel controller);

    public String getDataString() {
        return dataString;
    }

    public void setDataString(String string) {
        dataString = string;
    }

    @Override
    public void viewDidLoad() {
        super.viewDidLoad();
        dataLabel = getDataLabel();
        dataLabel.setText(dataString);
        dataLabel.setTextAlignment(NSTextAlignment.Center);
    }


}
