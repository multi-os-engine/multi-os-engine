package __package_name__.ui;

import org.moe.natj.general.Pointer;
import org.moe.natj.general.ann.*;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.SEL;
import org.moe.natj.objc.ann.ObjCClassName;
import org.moe.natj.objc.ann.Selector;

import apple.coregraphics.struct.CGPoint;
import apple.foundation.NSArray;
import apple.foundation.NSMutableArray;
import apple.scenekit.SCNAction;
import apple.scenekit.SCNCamera;
import apple.scenekit.SCNHitTestResult;
import apple.scenekit.SCNLight;
import apple.scenekit.SCNMaterial;
import apple.scenekit.SCNNode;
import apple.scenekit.SCNScene;
import apple.scenekit.SCNTransaction;
import apple.scenekit.SCNView;
import apple.scenekit.c.SceneKit;
import apple.uikit.UIColor;
import apple.uikit.UIDevice;
import apple.uikit.UIGestureRecognizer;
import apple.uikit.UITapGestureRecognizer;
import apple.uikit.UIViewController;
import apple.uikit.enums.UIInterfaceOrientationMask;
import apple.uikit.enums.UIUserInterfaceIdiom;

@org.moe.natj.general.ann.Runtime(ObjCRuntime.class)
@ObjCClassName("GameViewController")
@RegisterOnStartup
public class GameViewController extends UIViewController {

    protected GameViewController(Pointer peer) {
        super(peer);
    }

    @Owned
    @Selector("alloc")
    public static native GameViewController alloc();

    @Selector("init")
    public native GameViewController init();

    @Override
    public boolean prefersStatusBarHidden() {
        return true;
    }

    @Override
    public boolean shouldAutorotate() {
        return true;
    }

    @Override
    public long supportedInterfaceOrientations() {
        if (UIDevice.currentDevice().userInterfaceIdiom() == UIUserInterfaceIdiom.Phone) {
            return UIInterfaceOrientationMask.AllButUpsideDown;
        } else {
            return UIInterfaceOrientationMask.All;
        }
    }

    @Override
    public void viewDidLoad() {
        super.viewDidLoad();

        // For register SCNView and SCNHitTestResult classes
        SCNView scnViewReg = SCNView.alloc();
        SCNHitTestResult scnHitTestResult = SCNHitTestResult.alloc();

        // create a new scene
        SCNScene scene = SCNScene.sceneNamed("art.scnassets/ship.dae");

        // create and add a camera to the scene
        SCNNode cameraNode = SCNNode.node();
        cameraNode.setCamera(SCNCamera.camera());
        scene.rootNode().addChildNode(cameraNode);

        // place the camera
        cameraNode.setPosition(SceneKit.SCNVector3Make(0, 0, 15));

        // create and add a light to the scene
        SCNNode lightNode = SCNNode.node();
        lightNode.setLight(SCNLight.light());
        lightNode.light().setType(SceneKit.SCNLightTypeOmni());
        lightNode.setPosition(SceneKit.SCNVector3Make(0, 10, 10));
        scene.rootNode().addChildNode(lightNode);

        // create and add an ambient light to the scene
        SCNNode ambientLightNode = SCNNode.node();
        ambientLightNode.setLight(SCNLight.light());
        ambientLightNode.light().setType(SceneKit.SCNLightTypeAmbient());
        ambientLightNode.light().setColor(UIColor.darkGrayColor());
        scene.rootNode().addChildNode(ambientLightNode);

        // retrieve the ship node
        SCNNode ship = scene.rootNode().childNodeWithNameRecursively("ship", true);

        // animate the 3d object
        ship.runAction(SCNAction.repeatActionForever(SCNAction.rotateByXYZDuration(0, 2, 0, 1)));

        // retrieve the SCNView
        SCNView scnView = (SCNView)view();

        // set the scene to the view
        scnView.setScene(scene);

        // allows the user to manipulate the camera
        scnView.setAllowsCameraControl(true);

        // show statistics such as fps and timing information
        scnView.setShowsStatistics(true);

        // configure the view
        scnView.setBackgroundColor(UIColor.blackColor());

        // add a tap gesture recognizer
        UITapGestureRecognizer tapGesture = UITapGestureRecognizer.alloc().initWithTargetAction(this, new SEL("handleTap:"));
        NSMutableArray gestureRecognizers = NSMutableArray.array();
        gestureRecognizers.addObject(tapGesture);
        gestureRecognizers.addObjectsFromArray(scnView.gestureRecognizers());
        scnView.setGestureRecognizers(gestureRecognizers);
    }

    @Selector("handleTap:")
    @Generated
    void handleTap(Object object) {
        UIGestureRecognizer gestureRecognizer = (UIGestureRecognizer)object;
        // retrieve the SCNView
        SCNView scnView = (SCNView) view();

        // check what nodes are tapped
        CGPoint p = gestureRecognizer.locationInView(scnView);
        NSArray hitResults = scnView.hitTestOptions(p, null);

        // check that we clicked on at least one object
        if (hitResults.count() > 0) {
            // retrieved the first clicked object
            SCNHitTestResult results = (SCNHitTestResult) hitResults.objectAtIndex(0);

            // get its material
            final SCNMaterial material = results.node().geometry().firstMaterial();

            // highlight it
            SCNTransaction.begin();
            SCNTransaction.setAnimationDuration(0.5);

            // on completion - unhighlight
            SCNTransaction.setCompletionBlock(new SCNTransaction.Block_setCompletionBlock() {
                @Override
                public void call_setCompletionBlock() {
                    SCNTransaction.begin();
                    SCNTransaction.setAnimationDuration(0.5);

                    material.emission().setContents(UIColor.blackColor());

                    SCNTransaction.commit();
                }
            });

            material.emission().setContents(UIColor.redColor());
            SCNTransaction.commit();
        }
    }
}
